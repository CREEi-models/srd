# Simulateur de revenu disponible

Ce package contient le modèle de simulation du revenu developpe par la chaire [CREEi](http://www.creei.ca). La [documentation](https://creei-models.github.io/srd/) du modele devrait etre consulte concernant l'installation et l'utilisation du modele.