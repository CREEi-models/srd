# Simulateur de revenu disponible

Ce package contient le modèle de simulation du revenu développé par la chaire [CREEi](http://www.creei.ca). La [documentation](https://creei-models.github.io/srd/) du modèle devrait être consulté concernant l'installation et l'utilisation du modèle.